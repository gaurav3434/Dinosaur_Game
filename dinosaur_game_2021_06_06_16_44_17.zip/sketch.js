let dinosaur;
let Bird;
let counter=1;
let delay=120;
let jump=0;
let x=600;        // mountain's x position 
let B_x=-1500;    // bird positon x
let B_y=-7;       // bird positon y
let array=[];     // stores mountain heights 
let m=0;          // element position in array
let y=650;        // cactus x position
let array_2=[];   // number of cactus array
let z=65;         // spacing btn cactus
let cact=1;       // Quantity of cactus 
let bool= false;      // to bend down - triggered by mouse
let bool_3 = false;   // to stop the game when foul happens. 
let Y_limit=-210;     // cactus x position that triggers foul 
let bool_4=false;     // standing or bending pose after game over.
let score=0;


function preload()
{ //savanna = loadImage('mars.jpg');
  dinosaur= loadImage('Dinosaur.png');
  Bird= loadImage('Bird_.png');
}

function setup()
{  createCanvas(1100, 800);
   timer= createP('timer');
   setInterval(timeIt,delay);
   for (let i=0; i<100; i++)
     {
        array.push(random(300,440)); //  mountain height
        array_2.push(random(2,4));  //   number of cactus 
     }
}


function timeIt()
{   timer.html(counter);  
    counter++;
    if (counter>6)  
      { counter=1; 
      }
    if (counter==3)  
      { jump=0;
        delay=1;
      }
}

function draw()
{ 
  background(180,180,240);
  noStroke();
  mountain(x);
  land();
  if (cact==1)
  {cactus(y);}
  if (cact==2) 
  {cactus_2(y);}  
  if (cact==3) 
  {cactus_3(y);}
  
  if (bool_3==false)
    { print("B_x=  " +B_x)
      fill (0,225,0);
      noStroke();
      rect(500,240,110,50);
      stroke(0,10,50);
      textSize(30);
      fill(20,20,240);
      text('PRESS  SPACE  BAR  TO  JUMP',350,140);
      text('PRESS  MOUSE TO  BEND DOWN',350,200);
      text('Score : ',900,100);
      text(score,1000,100);
      text('START',510,275);
      push();
      scale(-2,2);   
      translate(0,155);
     if (bool_4==false) 
     {image(dinosaur,-207,8-jump,100,108,430,0,280,200);}
     
         image(Bird,B_x-100,B_y,70,40,370,0,140,80); //1 
  
     if (bool_4==true)
       { image(dinosaur,-207,40-jump,120,65,79,0,260,200);
         image(Bird,B_x-100,B_y,70,40,370,0,140,80);
       } 
     pop();
    }
  
  
    if (bool_3==true)  
      {  text('Score : ',850,100); 
         text(score,960,100);
    if (x<0 )
      {  x=1600;
         m++;
      }
     if (m==9)
      {
         m=0;
      }
  
    if (y<-450)
      {  y=random(900,1800);
         cact=int(array_2[m]);
      }
    print("B_x= " +B_x);
    if (B_x<-500)
      {  if (m%2==0)
         {B_y=55;}
         else if (B_y%2!=0)
                {B_y=-7; }
      }
  
    scale(-2,2);   
    translate(0,155);
 
  if (bool==false)
 {  if (counter==1)
      { image(dinosaur,-202,9-jump,100,100,79,0,280,200);
        image(Bird,-102+B_x,4+B_y,70,40,370,0,140,80); }  // 1
    if (counter==2)
      { image(dinosaur,-207,8-jump,100,100,430,0,280,200);
        image(Bird,-100+B_x,4+B_y,70,40,240,0,140,80); }   // 2
    if (counter==3)
      { image(dinosaur,-200,0-jump,100,100,79,170,280,200);
        image(Bird,-100+B_x,4+B_y,70,40,110,0,140,80); }   // 3
    if (counter==4)
      { image(dinosaur,-202,-10-jump,100,100,470,170,280,200);
        image(Bird,-92+B_x,4+B_y,70,40,-10,0,140,80);   }  // 4
    if (counter==5)
      { image(dinosaur,-203,-8-jump,100,100,89,380,280,200);
        image(Bird,-102+B_x,0+B_y,70,40,370,97,140,80); }  // 5
    if (counter==6)
      { image(dinosaur,-204,-10-jump,100,100,490,380,280,200);
        image(Bird,-100+B_x,4+B_y,70,40,110,108,140,80);
        score++;} // 6
  }
 
 if (bool==true)
 
 { 
   if (counter==1)
    { image(dinosaur,-202,42-jump,120,65,79,0,260,200);
    image(Bird,-102+B_x,4+B_y,70,40,370,0,140,80);} //1 
    
   if (counter==2)
    { image(dinosaur,-200,-78-jump,125,174,460,-360,260,530);
    image(Bird,-100+B_x,4+B_y,70,40,240,0,140,80);} //2 
 
  if (counter==3)
    {  image(dinosaur,-202,28-jump,125,80,79,160,280,240);
    image(Bird,-100+B_x,4+B_y,70,40,110,0,140,80);} //3

  if (counter==4)
    { image(dinosaur,-200,25-jump,125,78,480,170,280,245); 
    image(Bird,-92+B_x,4+B_y,70,40,-10,0,140,80); } //4
 
  if (counter==5)
    { image(dinosaur,-204,28-jump,125,80,89,380,280,250);
    image(Bird,-102+B_x,0+B_y,70,40,370,97,140,80);} //5
  
  if (counter==6)
    { image(dinosaur,-204,25-jump,125,80,490,380,280,250);
    image(Bird,-100+B_x,4+B_y,70,40,110,108,140,80);
    score++;} //6  
 }
  print ('bool= ' + bool);
 
// setting foul condition for different number of cactus
  if (cact==1)      
    { Y_limit=-120;}
  else if (cact==2)
    { Y_limit=-180;}
  else {Y_limit=-210;}
 
  
  x-=3;
  y-=11;
  B_x+=7.5;
  if (B_x>70 && (y)>900)
    { B_x=(-y)-70;}
  print("y=  "+ y);
 
 // stop when hit cactus
  if (y>(Y_limit) && y<20 && (jump==0 || jump==20)) 
    {  bool_3=false;
      if (jump==20 || bool==true)
        { bool_4=true;}
      if (jump==30 || bool==false)
        { bool_4=false;}
    }
  print("B_x=  " +B_x);
  print("Y=  " + y);
  
 // stop when hit bird flying high
   if ((B_x> -170 && B_x<-90) && (bool==false || jump>0) && B_y<0)
     {  bool_3=false;
        if (jump==20 || bool==true)
          { bool_4=true;}
        if (jump==30 || bool==false)
          { bool_4=false;}
     }
 
  // stop when hit bird flying low
  if ((B_x> -120 && B_x<-90) && (jump==20 || jump==0) && B_y>0)
    {   bool_3=false;
        if (jump==20 || bool==true)
          { bool_4=true;}
        if (jump==30 || bool==false)
          { bool_4=false;}
    }
}
}
function mountain(x)
{  
  fill(0,200,0);
  beginShape()
  curveVertex(x-240,500);
  curveVertex(x,500);
  curveVertex(x-120,array[m]);
  endShape(CLOSE);
}

function cactus(y)
{ push();
  translate(0,143);
  stroke(0,150,30);
  strokeWeight(5);
  line(y+300,300,y+300,310);
  line(y+310,303,y+310,319);
  line(y+300,313,y+317,325);
  line(y+320,336,y+345,320);
  line(y+334,323,y+334,309);
  line(y+345,321,y+344,309);
  strokeWeight(8);
  line(y+320,290,y+320,347);
  pop();
}

function cactus_2(y)
{ push();
  translate(0,143);
  stroke(0,150,30);
  strokeWeight(5);
  line(y+300,300,y+300,310);
  line(y+310,303,y+310,319);
  line(y+300,313,y+317,325);
  line(y+320,336,y+345,320);
  line(y+334,323,y+334,309);
  line(y+345,321,y+344,309);
  strokeWeight(8);
  line(y+320,290,y+320,347);
 
  strokeWeight(5);
  line(y+z+300,300,y+z+300,310);
  line(y+z+310,303,y+z+310,319);
  line(y+z+300,313,y+z+317,325);
  line(y+z+320,336,y+z+345,320);
  line(y+z+334,323,y+z+334,309);
  line(y+z+345,321,y+z+344,309);
  strokeWeight(8);
  line(y+z+320,290,y+z+320,347);
  pop();
  
}

function cactus_3(y)
{ push();
  translate(0,143);
  stroke(0,150,30);
  strokeWeight(5);
  line(y+300,300,y+300,310);
  line(y+310,303,y+310,319);
  line(y+300,313,y+317,325);
  line(y+320,336,y+345,320);
  line(y+334,323,y+334,309);
  line(y+345,321,y+344,309);
  strokeWeight(8);
  line(y+320,290,y+320,347);
 
  strokeWeight(5);
  line(y+z+300,300,y+z+300,310);
  line(y+z+310,303,y+z+310,319);
  line(y+z+300,313,y+z+317,325);
  line(y+z+320,336,y+z+345,320);
  line(y+z+334,323,y+z+334,309);
  line(y+z+345,321,y+z+344,309);
  strokeWeight(8);
  line(y+z+320,290,y+z+320,347);
 
  strokeWeight(5);
  line(y+z+z+300,300,y+z+z+300,310);
  line(y+z+z+310,303,y+z+z+310,319);
  line(y+z+z+300,313,y+z+z+317,325);
  line(y+z+z+320,336,y+z+z+345,320);
  line(y+z+z+334,323,y+z+z+334,309);
  line(y+z+z+345,321,y+z+z+344,309);
  strokeWeight(8);
  line(y+z+z+320,290,y+z+z+320,347);
  pop();
 
 
}


function land()
{
  fill(170,130,20);
  rect(0,490,1300,350);
  stroke(0);
}

function keyPressed() 
  { print('pressed');
    if (keyCode==32 && jump==0 && delay==1)
      { counter=5;
        if (bool==true)
          { jump=20;}     
        else { jump=40;}
        delay=0;
        print('space');
      }     
  }

function mousePressed() {
      if (mouseX>500 && mouseX<610 && mouseY<290 && mouseY>240 &&        bool_3==false)
        { bool_3=true;
          score=0;
          x=600;
          y=650;
          B_x=-1300;
        }
          bool=true;
}

function mouseReleased()
   
{   bool=false;
    
}